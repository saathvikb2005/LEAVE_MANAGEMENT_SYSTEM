package com.example.leavemanagment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeavemanagmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
